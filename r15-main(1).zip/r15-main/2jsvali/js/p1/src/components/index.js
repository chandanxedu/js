export { default as Education } from "./Education";
export { default as Header } from "./Header";
export { default as Hobby } from "./Hobby";
export { default as Project } from "./Project";
export { default as Skill } from "./Skill";
